import java.util.ArrayList;

public class Testing {

	
	public static void main(String[] args) {	
		int numHands = 5;
		
		BlackJackGameAutomator automator = new BlackJackGameAutomator(numHands);
		automator.initializeDeck();
		boolean flag_check = automator.dealInitial();
			if (!flag_check) {
				System.out.println("Error. Out of cards.");
			} else {
			System.out.println("-- Initial Deal --");
			automator.printHandsAndScore();
			ArrayList<Integer> blackjacks = automator.getBlackJacks();
			if (blackjacks.size() > 0) {
				System.out.print("Blackjack at ");
				for (int i : blackjacks) {
					System.out.print(i + ", ");
				}
				System.out.println("");
			} else {
				flag_check = automator.playAllHands();
				if (!flag_check) {
					System.out.println("All Cards are Used");
				} else {
					System.out.println("\n-- Game Has been Completed --");
					automator.printHandsAndScore();
					ArrayList<Integer> winners = automator.getWinners();
					if (winners.size() > 0) {
						System.out.print("Winners are: ");
						for (int i : winners) {
							System.out.print("Player " + i);
							System.out.println();
						}
						System.out.println("");
					} else {
						System.out.println("Draw. All players have busted.");
					}
				}
			}
		}
	}

}