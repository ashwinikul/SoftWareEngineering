
public enum Suit {

}
