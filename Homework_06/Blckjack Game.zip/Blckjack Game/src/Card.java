public abstract class Card {
	private boolean available = true;
	
	/* number or face that's on card - a number 2 through 10, 
	 * or 11 for Jack, 12 for Queen, 13 for King, or 1 for Ace 
	 */
	protected int faceValue;
	protected Pack Pack;

	public Card(int c, Pack s) {
		faceValue = c;
		Pack = s;
	}
	
	public abstract int value();
	
	public Pack Pack() { 
		return Pack; 
	}
	
	/* returns whether or not the card is available to be given out to someone */
	public boolean isAvailable() {
		return available;
	}
	
	public void markUnavailable() {
		available = false;
	}
	
	public void markAvailable() {
		available = true;
	}
	
	public void print() {
		String[] faceValues = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
		System.out.print(faceValues[faceValue - 1]);
		switch (Pack) {
		case Club:
			System.out.print("'C'");
			break;
		case Heart:
			System.out.print("'H'");
			break;
		case Diamond:
			System.out.print("'D'");
			break;
		case Spade:
			System.out.print("'S'");
			break;			
		}
		System.out.print(" ");
	}
}