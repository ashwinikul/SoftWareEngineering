
public enum Pack { 
	Club (0),
	Diamond (1),
	Heart (2),
	Spade (3);
	
	private int value;
	private Pack(int v) {
		value = v;
	}
	
	public int getValue() {
		return value;
	}
	
	public static Pack getPackFromValue(int value) {
		switch (value) {
		case 0:
			return Pack.Club;
		case 1:
			return Pack.Diamond;
		case 2:
			return Pack.Heart;
		case 3: 
			return Pack.Spade;
		default:
				return null;
		}
	}
}